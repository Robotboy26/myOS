KLPush:
  push 0

.looppush:
  mov ah, 0
  int 0x16   ; wait for keypress
  mov bx, ax

  cmp al, 0x0D  ; enter pressed?
  je .donepush      ; yes, we're done

  mov ah, 0x0E
  int 0x10      ; print out character

  mov ax, bx
  push ax

  jmp .looppush

.donepush:
  mov si, endline
  call printStr

  mov si, msg_push
  call printStr

  push 0 ; push the zero for the end of the string

  jmp kernelLoop
