KLRstring:
  mov si, msg_rstring
  call printStr

  mov di, buffer

  pop ax ; pop the first one here to skip the first zero
  stosb ; put char in buffer

.looprstring1:
  pop ax
  stosb ; store char in buffer

  cmp al, 0
  je .donerstring1

  jmp .looprstring1

.donerstring1:
  mov di, buffer
  mov bl, [di]   ; grab a byte from DI
  mov ax, 0
  mov al, bl
  push ax
  inc di
  jmp .looprstring2

.looprstring2:
  mov bl, [di]   ; grab a byte from DI

  mov al, bl
  push ax
  inc di

  cmp bl, 0 ; check if di char == 0 for the end termination
  je .donerstring2

  jmp .looprstring2

.donerstring2:
  jmp kernelLoop
