KLPop:
  pop ax

.looppop:
  pop ax

  cmp al, 0 ; if char is 0 jmp to done
  je .donepop

  mov ah, 0x0E
  int 0x10      ; print out character

  jmp .looppop ; else jump back to the top

.donepop:
  mov si, endline
  call printStr

  mov si, msg_pop
  call printStr

  jmp kernelLoop