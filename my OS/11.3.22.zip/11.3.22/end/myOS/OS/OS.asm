%define newline 0x0D, 0x0A
[org 0]   ; add 0 to label addresses
[bits 16]      ; tell the assembler we want 16 bit code

  ;stack breaks something testing needed!
  mov ax, 0  ; set up segments
  ;mov ds, ax
  ;mov es, ax
  mov ss, ax     ; setup stack
  mov sp, 0x7C00 ; stack grows downwards from 0x7C00

  ; very importand do not know why
  ; Set DS = CS 
  mov ax, cs
  mov ds, ax

  mov si, welcome
  call printStr

mainloop:
  mov si, prompt
  call printStr

  mov di, buffer
  call getString

  mov si, buffer
  cmp byte [si], 0  ; blank line?
  je mainloop       ; yes, ignore it

  mov si, buffer
  mov di, cmd_hello  ; "hello" command
  call strCmp
  jc .helloworld

  mov si, buffer
  mov di, cmd_help  ; "help" command
  call strCmp
  jc .help

  mov si, buffer
  mov di, cmd_echo  ; "echo" command
  call strCmp
  jc .echo

  mov si, buffer
  mov di, cmd_push  ; "push" command
  call strCmp
  jc .push

  mov si, buffer
  mov di, cmd_pop  ; "pop" command
  call strCmp
  jc .pop

  mov si, buffer
  mov di, cmd_rstring ; "rstring" command
  call strCmp
  jc .rstring

  mov si,badcommand
  call printStr 
  jmp mainloop  

.helloworld:
  mov si, msg_hello; prints the startup message for command hello
  call printStr

  jmp mainloop

.help:
  mov si, msg_help ; prints the startup message for command help
  call printStr

  jmp mainloop

.echo:
  mov si, prompt_echo
  call printStr

  mov di, buffer
  call getString
  
  mov si, buffer
  call printStr

  mov si, endline
  call printStr

  jmp mainloop

.rstring:
  mov si, msg_rstring
  call printStr

  mov di, buffer

  pop ax ; pop the first one here to skip the first zero
  stosb ; put char in buffer

.looprstring1:
  pop ax
  stosb ; store char in buffer

  cmp al, 0
  je .donerstring1

  jmp .looprstring1

.donerstring1:
  mov di, buffer
  mov bl, [di]   ; grab a byte from DI
  mov ax, 0
  mov al, bl
  push ax
  inc di
  jmp .looprstring2

.looprstring2:
  mov bl, [di]   ; grab a byte from DI

  mov al, bl
  push ax
  inc di

  cmp bl, 0 ; check if di char == 0 for the end termination
  je .donerstring2

  jmp .looprstring2

.donerstring2:
  jmp mainloop


.push:
  mov si, msg_push
  call printStr

  push 0

.looppush:
  mov ah, 0
  int 0x16   ; wait for keypress
  mov bx, ax

  cmp al, 0x0D  ; enter pressed?
  je .donepush      ; yes, we're done

  mov ah, 0x0E
  int 0x10      ; print out character

  mov ax, bx
  push ax

  jmp .looppush

.donepush:
  mov si, endline
  call printStr

  mov ax, 0
  push ax

  jmp mainloop

.pop:
  mov si, msg_pop
  call printStr

  pop ax
.looppop:
  pop ax

  cmp al, 0
  je .donepop

  mov ah, 0x0E
  int 0x10      ; print out character

  jmp .looppop

.donepop:
  mov si, endline
  call printStr

  jmp mainloop

welcome db 'Welcome to My OS!', newline, 'type help to see a list of commands', newline, 0
msg_hello db 'Hello World!', newline, 0
badcommand db 'Bad command entered.', newline, 0
prompt db '>', 0
prompt_echo db 'type what you want to echo on the line below', newline, 0
cmd_hello db 'hello', 0
cmd_help db 'help', 0
cmd_echo db 'echo', 0
cmd_push db 'push', 0
cmd_pop db 'pop', 0
cmd_rstring db 'rstring', 0
msg_help db 'My OS: Commands: hello, help, echo', newline, 0
msg_echo db 'str echoed', newline, 0
msg_push db 'pushed char',newline, 0
msg_pop db 'poped char', newline, 0
msg_rstring db 'reversing string', newline, 0
test_str db 'test', newline, 0
endline db newline, 0
buffer times 64 db 0

; ==========
; calls here
; ==========

; =====================
; include files go here
; =====================

%include "debug/print_test.asm"
%include "stringStuff/printStr.asm"
%include "stringStuff/strCmp.asm"
%include "userInput/getString.asm"

; padding
times 1024-($-$$) db 0